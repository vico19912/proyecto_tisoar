import 'package:flutter/material.dart';
import 'package:proyecto_tisoar/views/screens/widget/edit_drink/edit_drik_body.dart';
import 'package:proyecto_tisoar/views/screens/widget/general/bottom_bar.dart';

class EditDrinkScreen extends StatelessWidget {
  const EditDrinkScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: bodyEditDrink(context),
      bottomNavigationBar: bottomBarAdmin(),
    );
  }
}