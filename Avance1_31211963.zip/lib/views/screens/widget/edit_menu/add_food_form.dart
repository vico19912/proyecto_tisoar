import 'package:flutter/material.dart';
import 'package:proyecto_tisoar/views/screens/widget/edit_menu/add_food/dropdown.dart';
import 'package:proyecto_tisoar/views/screens/widget/general/input.dart';
import 'package:proyecto_tisoar/views/screens/widget/edit_menu/add_food/text_area.dart';
import 'package:proyecto_tisoar/views/screens/widget/edit_menu/add_food/upload_image.dart';
import 'package:proyecto_tisoar/views/screens/widget/general/button.dart';

Widget addFoodForm() {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildInputField("Nombre"),
            buildInputField("Precio"),
            buildDropdownField("Categoría"),
            buildImageUploadField(),
            buildDescriptionField(),
            SizedBox(height: 40),
            Center(
              child: CustomButton(text: 'Guardar', onPressed: (){})
            ),
          ],
        ),
      ),
    );
  }